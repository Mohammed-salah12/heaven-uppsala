import { getSite, getPage } from '@/lib/api';
import PageView from '@/components/PageView';

export const dynamic = 'force-dynamic';

export default async function Home({ searchParams }) {
  const lang = searchParams?.lang;
  const [site, page] = await Promise.all([getSite(lang), getPage('home', lang)]);
  return <PageView site={site} page={page} />;
}
