import { notFound } from 'next/navigation';
import { getSite, getPage } from '@/lib/api';
import PageView from '@/components/PageView';

export const dynamic = 'force-dynamic';

const KNOWN = ['bakfickan', 'konferens', 'festvaning', 'mat-meny', 'drink-meny'];

export default async function DynamicPage({ params, searchParams }) {
  const { slug } = params;
  if (!KNOWN.includes(slug)) notFound();
  const lang = searchParams?.lang;
  const [site, page] = await Promise.all([getSite(lang), getPage(slug, lang)]);
  if (site && !page) notFound();
  return <PageView site={site} page={page} />;
}
