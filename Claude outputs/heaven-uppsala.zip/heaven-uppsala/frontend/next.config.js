/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Load Google Fonts at runtime via the <link> in app/layout.js instead of
  // Next inlining them at build time (keeps builds working on restricted
  // networks; the browser fetches the fonts normally).
  optimizeFonts: false,
  // Plain <img> tags are used with the restaurant's CDN, so no image domain
  // config is required. If you switch to next/image, add remotePatterns here.
};

module.exports = nextConfig;
